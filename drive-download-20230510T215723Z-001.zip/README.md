**How to run the code:**<br>

1.    !git clone https://github.com/AJITKUMAR130012/Yolov5_table_Detection.git
2.    cd Yolov5_table_Detection/yolov5
3.    Install all the requiremement for the 
4.    Setup all the train and validation dataset, a/c to the given directory.
5.    Then go into the data folder, and **custom_coco128.yaml** and we have to make changes in that folder.
      ![custom_coco128](https://user-images.githubusercontent.com/60688738/222893182-583f657d-f5b6-4919-be3d-5f75c6a7adfc.png)
6.    done!
7.    Then run the running and testing script that is given in **.ipynb** file<br>

**Input**

![1_33](https://user-images.githubusercontent.com/60688738/222893582-0c4ce529-6e97-4292-ba2b-15c0c2b2f52e.jpg)<br>

**Output**

![1_33](https://user-images.githubusercontent.com/60688738/222893597-90ed1c1a-d4b3-46f0-8a66-d27879b84a52.jpg)


